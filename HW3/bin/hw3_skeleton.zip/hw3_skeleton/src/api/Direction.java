package api;

/**
 * Indication of direction for game moves.
 */
public enum Direction
{
  LEFT, RIGHT, UP, DOWN
}